package com.example.hibernateexample;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    public static void main(String[] args) {
    	
    	Configuration con = new Configuration().configure();
    	
    	SessionFactory sf =con.buildSessionFactory();
    	Session s =sf.openSession();
    	
    	Transaction t = s.beginTransaction();
    	
    	Employee e = new Employee();
    	
    	e.setId(1);
    	e.setName("John");
    	
    	Address ha= new Address();
    	ha.setCity("hyd");
    	ha.setState("telan");
    	ha.setStreet("ex strer");
    	ha.setZipCode("100");
    	
    	Address pa= new Address();
    	pa.setCity("che");
    	pa.setState("bang");
    	pa.setStreet("dn  strer");
    	pa.setZipCode("200");
    	
    	Address ta= new Address();
    	ta.setCity("bang");
    	ta.setState("bang");
    	ta.setStreet("xyz");
    	ta.setZipCode("500");
    	
    	e.setHomeAddress(ha);
    	e.setPermanentAddress(pa);
    	e.setTemporaryAddress(ta);
    	
    
    	s.save(e);
    	
    	t.commit();
    	

   
    	

    }
}
